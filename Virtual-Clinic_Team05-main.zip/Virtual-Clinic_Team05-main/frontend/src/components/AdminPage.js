import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { Button } from '@mui/material';
import './LoginForm.css'; // Import your CSS file for styling
import Header from "./Header";


function PatientPage() {
    const [showMore, setShowMore] = useState(false);
    const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const [Patient, setPatientData] = useState({});
  const getPatientData= async() =>{
    
    const Id = searchParams.get('Id');
    try{const response = await axios.get(`http://localhost:8000/getPatientById?Id=${Id}`.withCredentials=true ); 

    const P = response.data;

    setPatientData(P);
    console.log(Patient); 

  }
    catch (error) {
      alert('An error occurred:', error);
    }
  }



  const toggleShowMore = () => {
    setShowMore(!showMore);
  };
  const buttonContainerStyle = {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: '20px',
    alignItems: 'center',
    maxWidth: '600px',
    margin: '20px auto',
    padding: '20px',
    background: '#fff',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
    borderRadius: '8px',
  };

    return (
      <div>
      <Header />
      <h2>Hello Admin</h2>
      <br/>
      <div className="button-container" style={buttonContainerStyle}>
      {/* <Button onClick={() => window.location.href=`http://localhost:3000/addAdmin`}>Add Admin</Button> */}
        {/* <Button onClick={() => window.location.href=`http://localhost:3000/remove`}>Delete Users</Button> */}
        <Button onClick={() => window.location.href=`http://localhost:3000/requests`}>View Doctors Requests</Button>
        {/* <Button onClick={() => window.location.href=`http://localhost:3000/admin`}>Add Packages and Delete</Button> */}
        {/* <Button onClick={() => window.location.href=`http://localhost:3000/admin/update`}>Update PackageS</Button> */}
        {/* <Button onClick={() => window.location.href=`http://localhost:3000/CreateContract`}>Create Contract</Button> */}
        <Button onClick={() => window.location.href=`http://localhost:3000/ChangeMyPassword`}>ChangeMyPassword</Button>
      </div>
    </div>
  );
};

export default PatientPage;