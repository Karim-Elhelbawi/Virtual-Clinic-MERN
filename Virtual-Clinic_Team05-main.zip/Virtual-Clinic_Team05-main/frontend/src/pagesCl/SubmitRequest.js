import React, { useState } from 'react'
import RequestForm from '../components/RequestForm'

function SubmitRequest() {
    
    return(
        <div>
                    <RequestForm/>
        </div>
    )
}

// Email: </strong>{request.email}</p>
//             <p><strong>Date Of Birth: </strong>{request.dateOfBirth}</p>
//             <p><strong>Hourly Rate: </strong>{request.hourlyRate}</p>
//             <p><strong>Affilation: </strong>{request.affiliation}</p>
//             <p><strong>Educational Background: </strong>{request.educationalBackground}</p>
//             <p>{request.createdAt}</p>

export default SubmitRequest