import React from 'react';
import RemovePharmacistPatient from '../componentsPh/RemovePharmacistPatient';

const RemovePharPatPage = () => {
  return (
    <div>
      <h1>Remove Pharmacists/Patients</h1>
      <RemovePharmacistPatient />
    </div>


  );
};

export default RemovePharPatPage;
