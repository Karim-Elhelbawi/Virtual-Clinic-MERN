import React from 'react';


const ChangePassw = () => {
  return (
    <div>
      <p>FORGOT PASSWORD World</p>
    </div>
  );
};

export default ChangePassw;
