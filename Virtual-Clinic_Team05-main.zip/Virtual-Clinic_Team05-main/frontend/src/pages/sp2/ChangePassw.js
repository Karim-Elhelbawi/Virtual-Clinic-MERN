import React from 'react';

const ChangePassw = () => {
  return (
    <div>
      <p>CHANGE PASSWORD World</p>
    </div>
  );
};

export default ChangePassw;
